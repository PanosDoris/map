import React from 'react';

import Map from './screens/Map';
import Map from './screens/QRcode';

export default class App extends React.Component {
  render() {
    return (
      <Map />
	  <QRcode />
    );
  }
}
